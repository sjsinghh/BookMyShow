var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $http, $sce) {
    // var url="https://cors-anywhere.herokuapp.com/https://in.bookmyshow.com/serv/getData?cmd=GETTRAILERS&mtype=cs";// your request url    
    var url = "https://bypasscors.herokuapp.com/api/?url=" + encodeURIComponent("https://in.bookmyshow.com/serv/getData?cmd=GETTRAILERS&mtype=cs");
    var request = {}; // your request parameters
    var result = [];
    $scope.cRow = null;
    $scope.rowNo = [];
    $scope.mTrailers = [];
    $scope.mUrl = null;
    $scope.mTitle = null;
    $scope.willWatch = null;
    $scope.wontWatch = null;

    var headers = {
        // 'Authorization': 'Basic ' + btoa(username + ":" + password),
        'Access-Control-Allow-Origin': true,
        'Content-Type': 'jsonp; charset=utf-8',
        'X-Requested-With': "XMLHttpRequest"


    }
    $http.get(url, request, {
            headers
        })
        .then(function Success(response) {

                $scope.data = response.data[1];
                //	console.log($scope.data);
                $scope.loadData();
            },
            function Error(response) {
                result.push(response.data);
                $scope.Data = result;
                console.log(response.statusText + " " + response.status)
            });

    $scope.loadData = function() {

        var tempArr = [];
        var count = 0;
        var rowNo = 0;
        for (var i in $scope.data) {
            var temp = {};
            temp.EventCode = $scope.data[i].EventCode;
            temp.EventGenre = $scope.data[i].EventGenre;
            var DD = $scope.data[i].ShowDate;
            var sdate = DD.split(" ");
            console.log(sdate);
            temp.ShowDateD = sdate[0];
            var month = sdate[1].split(",");
            temp.ShowDateM = month[0];
            temp.EventLanguage = $scope.data[i].EventLanguage;
            temp.EventTitle = $scope.data[i].EventTitle;
            var trailer = $scope.data[i].TrailerURL;
            var spl = trailer.split("=");
            //console.log(spl[1]);
            if (spl[1]) {
                var spl2 = spl[1].split("&");
                var spl3 = spl2[0];
            }
            //console.log(spl3);
            temp.TrailerURL = spl3;
            temp.dwtsCount = $scope.data[i].dwtsCount;
            temp.wtsCount = $scope.data[i].wtsCount;
            temp.wtsPerc = $scope.data[i].wtsPerc;
            temp.csCount = temp.dwtsCount + temp.wtsCount;
            temp.rowNo = rowNo;

            tempArr.push(temp);
            count++;
            if (count == 6) {
                $scope.rowNo[rowNo] = false;
                $scope.mTrailers.push(tempArr);
                count = 0;
                rowNo++;
                tempArr = [];
            }
        }
        if (count > 0) {
            $scope.rowNo[rowNo] = false;
            $scope.mTrailers.push(tempArr);
        }

        console.log($scope.mTrailers);
    }


    $scope.chak = function(nRow) {
        $scope.rowNo[$scope.cRow] = false;
        $scope.rowNo[nRow] = true;
        $scope.cRow = nRow;
    }

    $scope.openTrailer = function(EventCode, nRow) {
        var trailer = $scope.data[EventCode].TrailerURL;
        var spl = trailer.split("=");
        var spl3;
        if (spl[1]) {
            var spl2 = spl[1].split("&");
            spl3 = spl2[0];
        }
        var cUrl = 'https://www.youtube.com/embed/' + spl3 + '?autoplay=1&rel=0&iv_load_policy=3';
        $scope.mUrl = $sce.trustAsResourceUrl(cUrl);
        var DD = $scope.data[EventCode].ShowDate;
        var sdate = DD.split(" ");
        console.log(sdate);
        $scope.ShowDateD = sdate[0];
        $scope.ShowDateY = sdate[2];
        var month = sdate[1].split(",");
        $scope.ShowDateM = month[0];

        console.log($scope.ShowDateY);
        $scope.mTitle = $scope.data[EventCode].EventTitle;
        $scope.willWatch = $scope.data[EventCode].wtsCount;
        $scope.wontWatch = $scope.data[EventCode].dwtsCount;
        $scope.wtsPerc = $scope.data[EventCode].wtsPerc;
        $scope.EventLanguage = $scope.data[EventCode].EventLanguage;
        if ($scope.cRow != null)
            $scope.rowNo[$scope.cRow] = false;
        $scope.rowNo[nRow] = true;
        $scope.cRow = nRow;


    }

});